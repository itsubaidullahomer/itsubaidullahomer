# Ubaidullah Omer
Full-Stack Engineer | Next.js, TypeScript, Node.js

Rahim Yar Khan, Pakistan | itsubaidullahomer@gmail.com | +92 3292380929
https://itsubaidullahomer.com | https://github.com/itsubaidullahomer | https://www.linkedin.com/in/itsubaidullahomer/

## Profile
Full-stack engineer building production applications with Next.js, React, TypeScript, Node.js and MongoDB. Leads engineering at Tututor.ai / EduNova across web products, shared backend services and mobile apps. Experience spans AI integrations, school management, payments, analytics and performance optimization. Available immediately; flexible to Australian business hours.

## Experience
### Lead Engineer / Full-Stack Engineer - Tututor.ai / EduNova
Nov 2023 - Present | Remote | Murcia, Spain
- Build and maintain a shared Express / MongoDB backend with approximately 1,000 API endpoints and 90 models, including school-scoped data access.
- Led a small team across mobile and web delivery; now work directly with the founder on product and engineering.
- Deliver Socket.io / Redis messaging, R2 file storage, Stripe and SEPA billing, and three React Native apps released on both app stores.
- Lead engineering across eight connected education products used by 20,000+ students, teachers and families.

### React Developer - Danzee Tech
Jan 2022 - Jan 2024 | Viby, Denmark
- Built reusable React components and hooks across client products, alongside Node.js / Express integrations, authentication and payment workflows.
- Delivered Jurri file, inbox and password-vault interfaces; reduced initial load time by approximately 40% through code splitting, lazy loading and bundle optimization.

## Selected projects
### Illume - AI business analytics
https://www.joinillume.com/
Built adaptive AI-generated analytics and dashboards for revenue, bookings and retention, with Boulevard, Zenoti and Vagaro data integrations.
React, Node.js, MongoDB, OpenAI, Chart.js, D3.js

### Viloi - AI writing SaaS
https://viloi.com
Built a paid AI writing product with OpenAI, Claude and Gemini fallbacks, JWT authentication, and Stripe subscriptions and webhooks.
React, Node.js, Express, MongoDB, Stripe

### Yaksport - Sports travel booking
https://yaksport.dk/
Built a Danish / English booking interface with search and filtering for a sports travel agency serving 100+ clubs.
React, Tailwind CSS, i18next, REST APIs

## Technical skills
- Frontend: React, TypeScript (4 years), Next.js (4 years), React Native (3 years), Redux Toolkit, Tailwind CSS, CSS Grid, Flexbox
- Backend: Node.js, Express, MongoDB, SQL (3+ years), PostgreSQL, GraphQL, REST APIs, WebSockets, Redis
- AI and integrations: OpenAI, Claude, Gemini, Stripe, JWT
- Testing and tools: Docker (3+ years), Jest, React Testing Library, Cypress, Git, Vite, Webpack
- Frontend practices: Shared component library or design-system maintenance; code reviews
