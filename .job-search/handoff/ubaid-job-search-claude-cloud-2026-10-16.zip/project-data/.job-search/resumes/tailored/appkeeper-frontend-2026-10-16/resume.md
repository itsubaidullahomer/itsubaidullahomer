# Ubaidullah Omer
Frontend Engineer | React, TypeScript, Product Delivery

Rahim Yar Khan, Pakistan | itsubaidullahomer@gmail.com | +92 3292380929
https://itsubaidullahomer.com | https://github.com/itsubaidullahomer | https://www.linkedin.com/in/itsubaidullahomer/

## Profile
Product-focused frontend engineer building React and TypeScript applications, reusable interfaces and data-rich workflows. Leads engineering at Tututor.ai / EduNova, with end-to-end experience across Node.js APIs, AI integrations and mobile apps. Earlier work includes analytics, file management and multilingual booking products. Available immediately.

## Experience
### Lead Engineer / Full-Stack Engineer - Tututor.ai / EduNova
Nov 2023 - Present | Remote | Murcia, Spain
- Lead engineering across eight connected education products used by 20,000+ students, teachers and families.
- Ship teacher workflows for lesson-topic chatbots, AI quiz generation, automated grading and class insights; moved AI calls and API keys server-side.
- Deliver Socket.io / Redis messaging, R2 file storage, Stripe and SEPA billing, and three React Native apps released on both app stores.
- Led a small team across mobile and web delivery; now work directly with the founder on product and engineering.

### React Developer - Danzee Tech
Jan 2022 - Jan 2024 | Viby, Denmark
- Built reusable React components and hooks across client products, alongside Node.js / Express integrations, authentication and payment workflows.
- Delivered Jurri file, inbox and password-vault interfaces; reduced initial load time by approximately 40% through code splitting, lazy loading and bundle optimization.

## Selected projects
### Illume - AI business analytics
https://www.joinillume.com/
Built adaptive AI-generated analytics and dashboards for revenue, bookings and retention, with Boulevard, Zenoti and Vagaro data integrations.
React, Node.js, MongoDB, OpenAI, Chart.js, D3.js

### Yaksport - Sports travel booking
https://yaksport.dk/
Built a Danish / English booking interface with search and filtering for a sports travel agency serving 100+ clubs.
React, Tailwind CSS, i18next, REST APIs

## Technical skills
- Frontend: React, TypeScript, Next.js, Redux Toolkit, RTK Query, Tailwind CSS
- Data and APIs: D3.js, Chart.js, REST APIs, WebSockets, Node.js, Express, MongoDB
- Testing and tools: Jest, React Testing Library, Cypress, Git, Vite, Webpack
