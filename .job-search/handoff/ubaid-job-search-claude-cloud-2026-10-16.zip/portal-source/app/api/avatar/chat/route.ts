import {
  ai,
  guard,
  getSession,
  json,
  redis,
  readBody,
  systemPrompt,
} from "@/lib/avatar/server";
import { TURN_LIMIT, TURN_SCRIPT, validMessage } from "@/lib/avatar/policy";
type Turn = { role: "user" | "model"; parts: { text: string }[] };
export async function POST(request: Request) {
  const denied = guard(request);
  if (denied) return denied;
  let lock: string | undefined;
  try {
    const body = await readBody(request);
    if (!validMessage(body.message))
      return json(
        { error: "Give me a message between 1 and 1,200 characters." },
        400,
      );
    const session = await getSession(request);
    if (!session)
      return json(
        {
          error:
            "That conversation has wrapped up. Let’s take the next one to a real call.",
          booking: true,
        },
        401,
      );
    const db = redis();
    lock = `avatar:busy:${session.id}`;
    const result = await db.eval(
      TURN_SCRIPT,
      [`avatar:session:${session.id}`, lock, `avatar:turns:${session.id}`],
      [TURN_LIMIT],
    );
    if (result !== "ok") {
      lock = undefined;
      return json(
        {
          error:
            result === "busy"
              ? "Let me finish this thought first."
              : "My conversation budget has called time. Want to book a call?",
          booking: result !== "busy",
        },
        429,
      );
    }
    const history =
      (await db.get<Turn[]>(`avatar:history:${session.id}`)) || [];
    const contents = [
      ...history.slice(-16),
      { role: "user" as const, parts: [{ text: body.message.trim() }] },
    ];
    const response = await ai().models.generateContent({
      model: process.env.GEMINI_TEXT_MODEL || "gemini-2.5-flash",
      contents,
      config: {
        systemInstruction: await systemPrompt(
          body.mode === "unfiltered" ? "unfiltered" : "polite",
        ),
        maxOutputTokens: 400,
        thinkingConfig: { thinkingBudget: 0 },
      },
    });
    const reply =
      response.text ||
      "I don’t have an answer to that one. Want to ask the real me?";
    if (session.expiresAt <= Date.now())
      return json(
        {
          error: "Time has called this conversation. Let’s book a call.",
          booking: true,
        },
        401,
      );
    await db.set(
      `avatar:history:${session.id}`,
      [...contents, { role: "model", parts: [{ text: reply }] }],
      { ex: Math.max(1, Math.ceil((session.expiresAt - Date.now()) / 1000)) },
    );
    return json({ reply });
  } catch {
    return json(
      {
        error: "That connection stumbled. Try again, or talk to the real me.",
        booking: true,
      },
      503,
    );
  } finally {
    if (lock)
      await redis()
        .del(lock)
        .catch(() => {});
  }
}
